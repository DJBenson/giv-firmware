ARMStore.bin - Use this file if loading BMS via DONGLE and Inverter. Inverter will then load to battery

BMS_ARM.bin - Use this file if loading DIRECTLY on Battery USB